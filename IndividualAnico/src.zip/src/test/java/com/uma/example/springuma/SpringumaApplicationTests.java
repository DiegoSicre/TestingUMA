package com.uma.example.springuma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringumaApplicationTests {

	@Test
	void contextLoads() {
	}

}
